import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import About from "./pages/About";
import HireTalentMulti from "./pages/HireTalentMulti";
import WorkWithUs from "./pages/WorkWithUs";
import Contact from "./pages/Contact";
import HiringStrategy from "./pages/HiringStrategy";
import HiringPlans from "./pages/HiringPlans";
import EOR from "./pages/services/EOR";
import TaaS from "./pages/services/TaaS";
import GlobalSourcing from "./pages/services/GlobalSourcing";
import TalentManagement from "./pages/services/TalentManagement";
import Blog from "./pages/Blog";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/about" element={<About />} />
          <Route path="/hiring-strategy" element={<HiringStrategy />} />
          <Route path="/hiring-plans" element={<HiringPlans />} />
          <Route path="/hire-talent" element={<HireTalentMulti />} />
          <Route path="/work-with-us" element={<WorkWithUs />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/services/eor" element={<EOR />} />
          <Route path="/services/taas" element={<TaaS />} />
          <Route path="/services/global-sourcing" element={<GlobalSourcing />} />
          <Route path="/services/talent-management" element={<TalentManagement />} />
          <Route path="/blog" element={<Blog />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
