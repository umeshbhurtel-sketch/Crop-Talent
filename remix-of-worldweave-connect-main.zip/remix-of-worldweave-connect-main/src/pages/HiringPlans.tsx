import { Layout } from "@/components/layout/Layout";
import { Helmet } from "react-helmet";
import { HiringPlansHero } from "@/components/hiring/HiringPlansHero";
import { HiringPlansCards } from "@/components/hiring/HiringPlansCards";
import { PlansComparisonStrip } from "@/components/hiring/PlansComparisonStrip";
import { HiringDecisionSupport } from "@/components/hiring/HiringDecisionSupport";
import { HiringBenefitsStrip } from "@/components/hiring/HiringBenefitsStrip";

const HiringPlans = () => {
  return (
    <Layout>
      <Helmet>
        <title>Hiring Plans | Logictive Solutions</title>
        <meta
          name="description"
          content="Explore our comprehensive hiring solutions: EOR for global compliance, TaaS for flexible experts, Global Talent Sourcing, and Talent Management services."
        />
        <meta property="og:title" content="Hiring Plans | Logictive Solutions" />
        <meta
          property="og:description"
          content="Choose the right hiring plan for your business needs. From EOR to TaaS and beyond."
        />
      </Helmet>

      {/* Hero Section */}
      <HiringPlansHero />

      {/* Benefits Strip */}
      <HiringBenefitsStrip />

      {/* Hiring Plans Cards */}
      <HiringPlansCards />

      {/* Comparison Strip */}
      <PlansComparisonStrip />

      {/* Decision Support Section */}
      <HiringDecisionSupport />
    </Layout>
  );
};

export default HiringPlans;
