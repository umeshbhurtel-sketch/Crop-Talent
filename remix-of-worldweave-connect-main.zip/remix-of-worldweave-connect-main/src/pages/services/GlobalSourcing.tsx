import { Layout } from "@/components/layout/Layout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Globe, CheckCircle2, ArrowRight, MapPin, Target, Award, Search, Briefcase, Users } from "lucide-react";
import { Helmet } from "react-helmet";
import { motion } from "framer-motion";

import heroGlobalTeam from "@/assets/hero-global-team.jpg";

const processSteps = [
  {
    number: 1,
    title: "Understand Job Role & Requirements",
    description: "Deep dive into your specific needs and ideal candidate profile.",
  },
  {
    number: 2,
    title: "Market Research & Talent Mapping",
    description: "Analyze global markets to identify optimal talent sources.",
  },
  {
    number: 3,
    title: "Multi-Country Recruitment Campaigns",
    description: "Launch targeted campaigns across multiple regions.",
  },
  {
    number: 4,
    title: "Candidate Sourcing & Headhunting",
    description: "Proactively identify and attract top-tier professionals.",
  },
  {
    number: 5,
    title: "Screening & Shortlisting",
    description: "Rigorously evaluate to ensure the best fit candidates.",
  },
  {
    number: 6,
    title: "Present Shortlisted Candidates",
    description: "Deliver qualified candidates ready for your final selection.",
  },
];

const benefitCards = [
  {
    icon: MapPin,
    title: "Multi-Region Access",
    description: "Tap into talent pools across Nepal, India, Argentina, Indonesia, Ukraine, and more.",
  },
  {
    icon: Search,
    title: "Precision Headhunting",
    description: "Targeted outreach to passive candidates who aren't actively job searching.",
  },
  {
    icon: Target,
    title: "Role-Specific Matching",
    description: "Every candidate is pre-vetted against your exact technical and cultural requirements.",
  },
  {
    icon: Award,
    title: "Full Hiring Control",
    description: "You make the final decisions—we deliver the candidates, you choose the best.",
  },
];

const whoIsItFor = [
  {
    title: "Tech Companies Scaling Fast",
    description: "Need multiple hires across different skill sets quickly",
  },
  {
    title: "HR Teams with Limited Bandwidth",
    description: "Want expert support for specialized or hard-to-fill roles",
  },
  {
    title: "Companies Exploring New Talent Markets",
    description: "Looking to access cost-effective global talent pools",
  },
];

const whenToUse = [
  "You need specialized talent for complex technical roles.",
  "Your internal team lacks bandwidth for extensive sourcing.",
  "You're looking for flexible hiring in different geographies.",
  "You want shortlisted talent within 2 weeks for immediate interviews.",
];

const GlobalSourcing = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1, delayChildren: 0.1 },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.4 } },
  };

  return (
    <Layout>
      <Helmet>
        <title>Global Talent Sourcing | Logictive Solutions</title>
        <meta
          name="description"
          content="Find top IT talent across the globe. Logictive's global sourcing connects you with pre-vetted candidates from high-skill regions worldwide."
        />
      </Helmet>

      {/* HERO SECTION */}
      <section className="py-20 lg:py-28 bg-background">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            {/* Left Content */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-muted border border-border/60 rounded-full text-muted-foreground text-sm font-medium mb-5">
                Global Sourcing
              </div>

              <h1 className="text-4xl md:text-5xl lg:text-[3.5rem] font-bold text-foreground mb-4 leading-[1.15]">
                Find Top Talent Across
                <br />
                the Globe
              </h1>

              <div className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
                <CheckCircle2 className="w-4 h-4 text-primary" />
                <span>Best for: Reach, speed, and accessing new talent markets</span>
              </div>

              <p className="text-lg text-muted-foreground leading-relaxed mb-8 max-w-xl">
                Our global sourcing connects you with pre-vetted candidates from high-skill regions worldwide. We handle the search, you make the hire—with full control over your selection.
              </p>

              <div className="flex flex-col sm:flex-row gap-3 mb-6">
                <Button size="lg" asChild className="shadow-md text-base h-11 px-6">
                  <Link to="/contact">
                    Start Your Search
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Link>
                </Button>
                <Button size="lg" variant="outline" asChild className="text-base h-11 px-6">
                  <Link to="/hire-talent">Explore Talent Pools</Link>
                </Button>
              </div>
            </motion.div>

            {/* Right Visual - Team Image */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="relative"
            >
              <div className="relative rounded-2xl overflow-hidden shadow-xl">
                <img 
                  src={heroGlobalTeam} 
                  alt="Global talent team collaboration" 
                  className="w-full h-auto object-cover aspect-[4/3]"
                />
                <div className="absolute bottom-4 right-4 bg-card/95 backdrop-blur-sm rounded-xl px-4 py-3 shadow-lg border border-border/60">
                  <div className="flex items-center gap-2">
                    <Users className="w-5 h-5 text-primary" />
                    <div>
                      <p className="text-sm font-semibold text-foreground">100K+</p>
                      <p className="text-xs text-muted-foreground">IT Professionals</p>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* WHAT GLOBAL SOURCING DELIVERS */}
      <section className="py-20 lg:py-24 bg-muted/30">
        <div className="container mx-auto px-4 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">What Global Sourcing Delivers</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Strategic recruitment that connects you with the right talent, fast
            </p>
          </motion.div>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6"
          >
            {benefitCards.map((card, index) => (
              <motion.div key={index} variants={itemVariants}>
                <Card className="p-6 h-full bg-card hover:shadow-lg transition-all duration-300 border-border/60 hover:border-primary/30">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                    <card.icon className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-semibold text-foreground mb-2">{card.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{card.description}</p>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* WHO IS THIS FOR */}
      <section className="py-20 lg:py-24 bg-background">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-start">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-5">
                Is Global Sourcing Right for You?
              </h2>
              <p className="text-muted-foreground mb-8 leading-relaxed">
                Our sourcing service is ideal for companies that want to expand their candidate pool beyond local markets—without managing the complexity themselves.
              </p>

              <div className="space-y-4">
                {whoIsItFor.map((item, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -16 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                    className="flex items-start gap-3"
                  >
                    <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <CheckCircle2 className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground">{item.title}</h4>
                      <p className="text-sm text-muted-foreground">{item.description}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              <Card className="p-6 bg-card border-border/60">
                <h3 className="font-semibold text-foreground mb-5">When to Use Global Sourcing</h3>
                <ul className="space-y-3">
                  {whenToUse.map((item, index) => (
                    <li key={index} className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
                      <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                      <span className="text-sm text-foreground">{item}</span>
                    </li>
                  ))}
                </ul>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      {/* HOW GLOBAL SOURCING WORKS */}
      <section className="py-20 lg:py-24 bg-muted/30">
        <div className="container mx-auto px-4 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">How Global Sourcing Works</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              From job brief to shortlisted candidates—a proven process
            </p>
          </motion.div>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto"
          >
            {processSteps.map((step, index) => (
              <motion.div key={step.number} variants={itemVariants}>
                <Card className="p-6 h-full bg-card border-border/60 hover:shadow-md transition-all">
                  <div className="w-10 h-10 rounded-xl bg-primary text-primary-foreground flex items-center justify-center font-bold text-lg mb-4">
                    {step.number}
                  </div>
                  <h4 className="font-semibold text-foreground mb-2">{step.title}</h4>
                  <p className="text-sm text-muted-foreground leading-relaxed">{step.description}</p>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* CTA SECTION */}
      <section className="py-20 lg:py-24 bg-primary">
        <div className="container mx-auto px-4 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="max-w-2xl mx-auto text-center"
          >
            <Briefcase className="w-12 h-12 mx-auto mb-6 text-primary-foreground/80" />
            <h3 className="text-3xl lg:text-4xl font-bold text-primary-foreground mb-4">
              Let's Map Your Ideal Talent
            </h3>
            <p className="text-primary-foreground/80 mb-8 leading-relaxed">
              Share your hiring needs and we'll show you the best talent markets for your roles—with a tailored sourcing strategy.
            </p>
            <Button size="lg" variant="outline" asChild className="bg-primary-foreground text-primary hover:bg-primary-foreground/90 border-0 shadow-md text-base h-11 px-6">
              <Link to="/contact">
                Start Your Search
                <ArrowRight className="w-4 h-4 ml-2" />
              </Link>
            </Button>
          </motion.div>
        </div>
      </section>
    </Layout>
  );
};

export default GlobalSourcing;
