import { Layout } from "@/components/layout/Layout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Zap, CheckCircle2, ArrowRight, Clock, RefreshCw, Shield, Layers, Users, ChevronDown } from "lucide-react";
import { Helmet } from "react-helmet";
import { motion } from "framer-motion";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

import heroTalentNetwork from "@/assets/hero-talent-network.jpg";

const processSteps = [
  {
    number: 1,
    title: "Understand Client Needs",
    description: "Deep dive into your project requirements and team dynamics.",
  },
  {
    number: 2,
    title: "Talent Matching",
    description: "Leverage AI to match with pre-vetted professionals globally.",
  },
  {
    number: 3,
    title: "Onboarding & Integration",
    description: "Seamlessly integrate new talent into your existing workflows.",
  },
  {
    number: 4,
    title: "Ongoing Support",
    description: "Dedicated account management and continuous support.",
  },
];

const benefitCards = [
  {
    icon: Clock,
    title: "Rapid Deployment",
    description: "Get skilled professionals on your team in days, not months.",
  },
  {
    icon: Layers,
    title: "Flexible Scaling",
    description: "Scale up or down instantly based on project schedules and timelines.",
  },
  {
    icon: RefreshCw,
    title: "Replacement Guarantee",
    description: "Not satisfied? We'll replace the resource at no extra cost.",
  },
  {
    icon: Shield,
    title: "Zero Long-Term Risk",
    description: "No permanent hiring overhead—pay only for what you use.",
  },
];

const whoIsItFor = [
  {
    title: "Project-Based Organizations",
    description: "Need talent for specific projects without permanent hires",
  },
  {
    title: "Startups with Variable Needs",
    description: "Scaling fast and need flexibility in team composition",
  },
  {
    title: "Enterprises Filling Skill Gaps",
    description: "Augmenting internal teams with specialized expertise",
  },
];

const TaaS = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1, delayChildren: 0.1 },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.4 } },
  };

  return (
    <Layout>
      <Helmet>
        <title>Talent-as-a-Service (TaaS) | Logictive Solutions</title>
        <meta
          name="description"
          content="Flexible on-demand access to skilled IT professionals. Scale your team instantly with Logictive's Talent-as-a-Service solution."
        />
      </Helmet>

      {/* HERO SECTION */}
      <section className="py-20 lg:py-28 bg-background">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            {/* Left Content */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-secondary/10 border border-secondary/20 rounded-full text-secondary text-sm font-medium mb-5">
                <Zap className="w-3.5 h-3.5" />
                Talent-as-a-Service
              </div>

              <h1 className="text-4xl md:text-5xl lg:text-[3.5rem] font-bold text-foreground mb-4 leading-[1.15]">
                On-Demand Talent
                <br />
                <span className="text-secondary">When You Need It</span>
              </h1>

              <p className="text-lg text-muted-foreground leading-relaxed mb-8 max-w-xl">
                Access skilled IT professionals on demand—scale your team up or down without long-term commitments. Perfect for projects, seasonal needs, or rapid growth.
              </p>

              <div className="flex flex-col sm:flex-row gap-3 mb-6">
                <Button size="lg" asChild className="shadow-md bg-secondary hover:bg-secondary/90 text-base h-11 px-6">
                  <Link to="/contact">
                    Get Talent Fast
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Link>
                </Button>
                <Button size="lg" variant="outline" asChild className="text-base h-11 px-6">
                  <Link to="/hire-talent">See How It Works</Link>
                </Button>
              </div>
            </motion.div>

            {/* Right Visual - Team Image */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="relative"
            >
              <div className="relative rounded-2xl overflow-hidden shadow-xl">
                <img 
                  src={heroTalentNetwork} 
                  alt="On-demand talent working remotely" 
                  className="w-full h-auto object-cover aspect-[4/3]"
                />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* WHAT TAAS DELIVERS */}
      <section className="py-20 lg:py-24 bg-muted/30">
        <div className="container mx-auto px-4 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">What TaaS Delivers</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Flexible talent access that adapts to your business needs, quickly and efficiently
            </p>
          </motion.div>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6"
          >
            {benefitCards.map((card, index) => (
              <motion.div key={index} variants={itemVariants}>
                <Card className="p-6 h-full bg-card hover:shadow-lg transition-all duration-300 border-border/60 hover:border-secondary/30">
                  <div className="w-12 h-12 rounded-xl bg-secondary/10 flex items-center justify-center mb-4">
                    <card.icon className="w-6 h-6 text-secondary" />
                  </div>
                  <h3 className="font-semibold text-foreground mb-2">{card.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{card.description}</p>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* IS TAAS RIGHT FOR YOU */}
      <section className="py-20 lg:py-24 bg-background">
        <div className="container mx-auto px-4 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="max-w-3xl mx-auto"
          >
            <div className="text-center mb-10">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Is TaaS Right for Your Business?</h2>
              <p className="text-muted-foreground">
                Talent-as-a-Service is ideal for organizations that need flexibility—whether you're scaling for a project, filling temporary gaps, or testing new team structures.
              </p>
            </div>

            <Accordion type="single" collapsible className="space-y-3">
              {whoIsItFor.map((item, index) => (
                <AccordionItem 
                  key={index} 
                  value={`item-${index}`}
                  className="border border-border/60 rounded-xl px-5 bg-card data-[state=open]:shadow-md transition-all"
                >
                  <AccordionTrigger className="hover:no-underline py-4">
                    <div className="flex items-center gap-3 text-left">
                      <CheckCircle2 className="w-5 h-5 text-secondary flex-shrink-0" />
                      <span className="font-semibold text-foreground">{item.title}</span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="pb-4 pl-8 text-muted-foreground">
                    {item.description}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </motion.div>
        </div>
      </section>

      {/* COMBINE WITH EOR */}
      <section className="py-16 lg:py-20 bg-muted/50">
        <div className="container mx-auto px-4 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="max-w-3xl mx-auto text-center"
          >
            <h3 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
              Combine TaaS with EOR for Full Compliance
            </h3>
            <p className="text-muted-foreground mb-6 leading-relaxed">
              Need flexible talent in international markets? Pair TaaS with our Employer of Record service to get on-demand professionals with full legal and HR compliance—no entity required.
            </p>
            <Button variant="outline" asChild className="text-base h-11 px-6">
              <Link to="/services/eor">
                Learn About EOR
                <ArrowRight className="w-4 h-4 ml-2" />
              </Link>
            </Button>
          </motion.div>
        </div>
      </section>

      {/* HOW TAAS WORKS */}
      <section className="py-20 lg:py-24 bg-background">
        <div className="container mx-auto px-4 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">How TaaS Works</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              From need to deployment—fast, flexible, and hassle-free
            </p>
          </motion.div>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-5xl mx-auto"
          >
            {processSteps.map((step, index) => (
              <motion.div key={step.number} variants={itemVariants}>
                <Card className="p-6 h-full bg-card border-border/60 hover:shadow-md transition-all relative">
                  <div className="w-10 h-10 rounded-xl bg-secondary text-secondary-foreground flex items-center justify-center font-bold text-lg mb-4">
                    {step.number}
                  </div>
                  <h4 className="font-semibold text-foreground mb-2">{step.title}</h4>
                  <p className="text-sm text-muted-foreground leading-relaxed">{step.description}</p>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* CTA SECTION */}
      <section className="py-20 lg:py-24 bg-secondary">
        <div className="container mx-auto px-4 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="max-w-2xl mx-auto text-center"
          >
            <Users className="w-12 h-12 mx-auto mb-6 text-secondary-foreground/80" />
            <h3 className="text-3xl lg:text-4xl font-bold text-secondary-foreground mb-4">
              Ready to Scale Your Team?
            </h3>
            <p className="text-secondary-foreground/80 mb-8 leading-relaxed">
              Tell us what you need and we'll match you with pre-vetted professionals ready to start—with zero long-term commitment.
            </p>
            <Button size="lg" variant="outline" asChild className="bg-secondary-foreground text-secondary hover:bg-secondary-foreground/90 border-0 shadow-md text-base h-11 px-6">
              <Link to="/contact">
                Get Talent in 48 Hours
                <ArrowRight className="w-4 h-4 ml-2" />
              </Link>
            </Button>
          </motion.div>
        </div>
      </section>
    </Layout>
  );
};

export default TaaS;
