import { Layout } from "@/components/layout/Layout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Shield, CheckCircle2, ArrowRight, Globe2, Scale, Building2, CreditCard, Users, FileCheck } from "lucide-react";
import { Helmet } from "react-helmet";
import { motion } from "framer-motion";

const processSteps = [
  {
    number: 1,
    title: "Understand Client & Compliance Needs",
    description: "Assess your business requirements and local compliance regulations to tailor the perfect EOR solution.",
  },
  {
    number: 2,
    title: "Legal Employment Setup",
    description: "Establish a secure legal employer relationship in target countries, ensuring full adherence to local laws.",
  },
  {
    number: 3,
    title: "Onboarding & HR Orientation",
    description: "Provide comprehensive onboarding for new team members and integrate them smoothly into your global workforce.",
  },
  {
    number: 4,
    title: "Compliance Monitoring",
    description: "Conduct ongoing compliance tracking and regulatory updates to keep your global workforce fully compliant.",
  },
];

const benefitCards = [
  {
    icon: Scale,
    title: "Full Legal Compliance",
    description: "We handle all employment laws, tax obligations, and regulatory requirements in each country, ensuring seamless global operations.",
  },
  {
    icon: CreditCard,
    title: "Seamless Payroll",
    description: "Complete payroll processing, benefits administration, and local currency payments tailored to global standards.",
  },
  {
    icon: Building2,
    title: "No Entity Required",
    description: "Hire in any country without the cost and complexity of setting up a local subsidiary, accelerating market entry.",
  },
  {
    icon: Shield,
    title: "Risk Protection",
    description: "Eliminate misclassification risks and ensure robust worker protections are in place, safeguarding your business.",
  },
];

const whoIsItFor = [
  {
    title: "Companies Expanding Globally",
    description: "Want to hire in new markets without setting up legal entities.",
  },
  {
    title: "Startups & Scale-ups",
    description: "Need to onboard international talent quickly and compliantly.",
  },
  {
    title: "Remote-First Organizations",
    description: "Building distributed teams across multiple countries.",
  },
];

const whenToUse = [
  "Testing new markets before full expansion.",
  "Hiring a single employee in a new country.",
  "Avoiding contractor misclassification risks.",
  "Offering competitive benefits to international hires.",
];

const EOR = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1, delayChildren: 0.1 },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.4 } },
  };

  return (
    <Layout>
      <Helmet>
        <title>Employer of Record (EOR) Services | Logictive Solutions</title>
        <meta
          name="description"
          content="Hire globally without setting up local entities. Logictive's EOR services handle legal, compliance, and payroll for seamless international hiring."
        />
      </Helmet>

      {/* HERO SECTION */}
      <section className="py-20 lg:py-28 bg-background">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            {/* Left Content */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-primary/10 border border-primary/20 rounded-full text-primary text-sm font-medium mb-5">
                <Shield className="w-3.5 h-3.5" />
                Employer of Record
              </div>

              <h1 className="text-4xl md:text-5xl lg:text-[3.5rem] font-bold text-foreground mb-4 leading-[1.15]">
                Hire Globally with
                <br />
                <span className="text-primary">Full Legal Clarity</span>
              </h1>

              <p className="text-muted-foreground mb-3 text-sm">
                Best for: Compliance, payroll, and legal employer coverage
              </p>

              <p className="text-lg text-muted-foreground leading-relaxed mb-8 max-w-xl">
                Expand into new markets without setting up local entities. We become the legal employer, handling all compliance, payroll, and HR administration—while you retain full operational control.
              </p>

              <div className="flex flex-col sm:flex-row gap-3 mb-6">
                <Button size="lg" asChild className="shadow-md text-base h-11 px-6">
                  <Link to="/contact">
                    Talk to an EOR Expert
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Link>
                </Button>
                <Button size="lg" variant="outline" asChild className="text-base h-11 px-6">
                  <Link to="/hire-talent">See How It Works</Link>
                </Button>
              </div>
            </motion.div>

            {/* Right Visual - Compliance Badge */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="relative flex items-center justify-center"
            >
              <div className="relative w-full max-w-sm mx-auto">
                <Card className="p-8 bg-card border border-border/60 rounded-2xl shadow-lg">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-10 h-10 rounded-full bg-green-500/10 flex items-center justify-center">
                      <CheckCircle2 className="w-5 h-5 text-green-600" />
                    </div>
                    <span className="text-sm font-medium text-muted-foreground">100% Compliant</span>
                  </div>
                  
                  <div className="flex items-center justify-center py-6">
                    <div className="relative">
                      <div className="w-32 h-32 rounded-full bg-primary/10 flex items-center justify-center">
                        <Globe2 className="w-16 h-16 text-primary" />
                      </div>
                      <div className="absolute -top-1 -right-1 w-10 h-10 rounded-full bg-green-500 flex items-center justify-center shadow-lg">
                        <CheckCircle2 className="w-5 h-5 text-white" />
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground pt-4 border-t border-border/50">
                    <Globe2 className="w-4 h-4 text-primary" />
                    <span>8+ Countries Covered</span>
                  </div>
                </Card>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* WHAT EOR COVERS */}
      <section className="py-20 lg:py-24 bg-muted/30">
        <div className="container mx-auto px-4 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">What EOR Covers</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Complete employment infrastructure without the complexity. Our EOR solution integrates seamlessly with your operations.
            </p>
          </motion.div>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6"
          >
            {benefitCards.map((card, index) => (
              <motion.div key={index} variants={itemVariants}>
                <Card className="p-6 h-full bg-card hover:shadow-lg transition-all duration-300 border-border/60 hover:border-primary/30">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                    <card.icon className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-semibold text-foreground mb-2">{card.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{card.description}</p>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* WHO IS THIS FOR */}
      <section className="py-20 lg:py-24 bg-background">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-start">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              <span className="text-primary font-medium text-sm uppercase tracking-wider mb-3 block">Who Is This For?</span>
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-5">
                Is EOR Right for Your Business?
              </h2>
              <p className="text-muted-foreground mb-8 leading-relaxed">
                Our Employer of Record service is designed for organizations that need to hire international talent quickly and compliantly—without the overhead of entity establishment.
              </p>

              <div className="space-y-4">
                {whoIsItFor.map((item, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -16 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                    className="flex items-start gap-3"
                  >
                    <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <CheckCircle2 className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground">{item.title}</h4>
                      <p className="text-sm text-muted-foreground">{item.description}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              <Card className="p-6 bg-card border-border/60">
                <h3 className="font-semibold text-foreground mb-5">When to Use EOR</h3>
                <ul className="space-y-3">
                  {whenToUse.map((item, index) => (
                    <li key={index} className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
                      <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                      <span className="text-sm text-foreground">{item}</span>
                    </li>
                  ))}
                </ul>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      {/* HOW EOR WORKS */}
      <section className="py-20 lg:py-24 bg-muted/30">
        <div className="container mx-auto px-4 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">How EOR Works</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              A structured process to get you hiring globally in weeks, not months. Our streamlined approach ensures efficiency.
            </p>
          </motion.div>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto"
          >
            {processSteps.map((step, index) => (
              <motion.div key={step.number} variants={itemVariants}>
                <Card className="p-6 h-full bg-card border-border/60 hover:shadow-md transition-all">
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-xl bg-primary text-primary-foreground flex items-center justify-center font-bold text-lg flex-shrink-0">
                      {step.number}
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground mb-2">{step.title}</h4>
                      <p className="text-sm text-muted-foreground leading-relaxed">{step.description}</p>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* CTA SECTION */}
      <section className="py-20 lg:py-24 bg-primary">
        <div className="container mx-auto px-4 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="max-w-2xl mx-auto text-center"
          >
            <Users className="w-12 h-12 mx-auto mb-6 text-primary-foreground/80" />
            <p className="text-primary-foreground/70 text-sm font-medium uppercase tracking-wider mb-3">
              Ready to expand your global team?
            </p>
            <h3 className="text-3xl lg:text-4xl font-bold text-primary-foreground mb-4">
              Let's Discuss Your EOR Needs
            </h3>
            <p className="text-primary-foreground/80 mb-8 leading-relaxed">
              Our HR experts will help you understand the best approach for hiring in your target markets—with zero obligations.
            </p>
            <Button size="lg" variant="outline" asChild className="bg-primary-foreground text-primary hover:bg-primary-foreground/90 border-0 shadow-md text-base h-11 px-6">
              <Link to="/contact">
                Talk to an HR Expert
                <ArrowRight className="w-4 h-4 ml-2" />
              </Link>
            </Button>
          </motion.div>
        </div>
      </section>
    </Layout>
  );
};

export default EOR;
