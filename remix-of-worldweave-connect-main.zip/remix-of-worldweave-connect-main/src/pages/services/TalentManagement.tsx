import { Layout } from "@/components/layout/Layout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Users, CheckCircle2, ArrowRight, TrendingUp, Heart, GraduationCap, MessageSquare } from "lucide-react";
import { Helmet } from "react-helmet";
import { motion } from "framer-motion";

const processSteps = [
  {
    number: 1,
    title: "Assess Workforce Needs",
    description: "Understand your team structure and development requirements.",
  },
  {
    number: 2,
    title: "Onboard New Talent",
    description: "Comprehensive onboarding for seamless team integration.",
  },
  {
    number: 3,
    title: "Engagement Programs",
    description: "Initiatives to keep your workforce motivated and connected.",
  },
  {
    number: 4,
    title: "Training & Development",
    description: "Continuous learning to enhance skills and capabilities.",
  },
];

const benefitCards = [
  {
    icon: Heart,
    title: "Employee Engagement",
    description: "Programs designed to keep remote teams connected, motivated, and productive.",
  },
  {
    icon: TrendingUp,
    title: "Performance Growth",
    description: "Regular reviews, goal tracking, and development pathways for every team member.",
  },
  {
    icon: GraduationCap,
    title: "Skill Development",
    description: "Continuous learning opportunities to keep your workforce competitive.",
  },
  {
    icon: MessageSquare,
    title: "Feedback Culture",
    description: "Structured feedback loops that improve communication and team dynamics.",
  },
];

const lifecycleCards = [
  { title: "Onboarding", description: "Structured integration for new hires" },
  { title: "Performance Reviews", description: "Regular check-ins and goal alignment" },
  { title: "Training Programs", description: "Skills development and certification" },
  { title: "Engagement Initiatives", description: "Team building and recognition" },
  { title: "Career Pathing", description: "Growth opportunities and succession" },
  { title: "Full Lifecycle", description: "HR Support", highlighted: true },
];

const whoIsItFor = [
  {
    title: "Remote-First Companies",
    description: "Building culture and engagement across distributed teams.",
  },
  {
    title: "Growing Organizations",
    description: "Scaling teams while maintaining performance standards.",
  },
  {
    title: "Companies with High Turnover",
    description: "Looking to improve retention and employee satisfaction.",
  },
];

const TalentManagement = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1, delayChildren: 0.1 },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.4 } },
  };

  return (
    <Layout>
      <Helmet>
        <title>Talent Management | Logictive Solutions</title>
        <meta
          name="description"
          content="Engage, manage, and develop your remote workforce for long-term success. Comprehensive talent management from onboarding to retention."
        />
      </Helmet>

      {/* HERO SECTION */}
      <section className="py-20 lg:py-28 bg-background">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            {/* Left Content */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-secondary/10 border border-secondary/20 rounded-full text-secondary text-sm font-medium mb-5">
                <Users className="w-3.5 h-3.5" />
                Talent Management
              </div>

              <h1 className="text-4xl md:text-5xl lg:text-[3.5rem] font-bold text-foreground mb-4 leading-[1.15]">
                Grow & Retain Your
                <br />
                <span className="text-secondary">Best People</span>
              </h1>

              <p className="text-muted-foreground mb-3 text-sm">
                Best for: Retention, performance, and workforce development
              </p>

              <p className="text-lg text-muted-foreground leading-relaxed mb-8 max-w-xl">
                Keep your remote workforce engaged, productive, and growing. From onboarding to succession planning—we help you build a high-performing team culture that lasts.
              </p>

              <div className="flex flex-col sm:flex-row gap-3 mb-6">
                <Button size="lg" asChild className="shadow-md bg-secondary hover:bg-secondary/90 text-base h-11 px-6">
                  <Link to="/contact">
                    Build Your Team Culture
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Link>
                </Button>
                <Button size="lg" variant="outline" asChild className="text-base h-11 px-6">
                  <Link to="/hire-talent">Explore Services</Link>
                </Button>
              </div>
            </motion.div>

            {/* Right Visual - Lifecycle Grid */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="relative"
            >
              <div className="grid grid-cols-2 gap-3">
                {lifecycleCards.map((card, index) => (
                  <motion.div
                    key={card.title}
                    initial={{ opacity: 0, y: 16 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: 0.3 + index * 0.08 }}
                  >
                    <Card 
                      className={`p-4 h-full transition-all duration-300 ${
                        card.highlighted 
                          ? "bg-primary text-primary-foreground border-primary" 
                          : "bg-card border-border/60 hover:shadow-md hover:border-secondary/30"
                      }`}
                    >
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center mb-2 ${
                        card.highlighted ? "bg-primary-foreground/10" : "bg-muted"
                      }`}>
                        {card.highlighted ? (
                          <Users className="w-4 h-4" />
                        ) : (
                          <div className="w-4 h-4 rounded bg-secondary/20" />
                        )}
                      </div>
                      <h4 className={`font-semibold text-sm mb-0.5 ${card.highlighted ? "" : "text-foreground"}`}>
                        {card.title}
                      </h4>
                      <p className={`text-xs ${card.highlighted ? "opacity-90" : "text-muted-foreground"}`}>
                        {card.description}
                      </p>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* WHAT TALENT MANAGEMENT DELIVERS */}
      <section className="py-20 lg:py-24 bg-muted/30">
        <div className="container mx-auto px-4 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">What Talent Management Delivers</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Comprehensive people management that drives engagement and results
            </p>
          </motion.div>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6"
          >
            {benefitCards.map((card, index) => (
              <motion.div key={index} variants={itemVariants}>
                <Card className="p-6 h-full bg-card hover:shadow-lg transition-all duration-300 border-border/60 hover:border-secondary/30">
                  <div className="w-12 h-12 rounded-xl bg-secondary/10 flex items-center justify-center mb-4">
                    <card.icon className="w-6 h-6 text-secondary" />
                  </div>
                  <h3 className="font-semibold text-foreground mb-2">{card.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{card.description}</p>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* WHO IS THIS FOR */}
      <section className="py-20 lg:py-24 bg-background">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              <span className="text-secondary font-medium text-sm uppercase tracking-wider mb-3 block">Who Is This For?</span>
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-5">
                Is Talent Management Right for You?
              </h2>
              <p className="text-muted-foreground mb-8 leading-relaxed">
                Our talent management services are designed for organizations that want to invest in their people—improving engagement, performance, and long-term retention.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              <div className="space-y-4">
                {whoIsItFor.map((item, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: 16 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                    className="flex items-start gap-3 p-4 rounded-xl bg-muted/50"
                  >
                    <div className="w-6 h-6 rounded-full bg-secondary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <CheckCircle2 className="w-4 h-4 text-secondary" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground">{item.title}</h4>
                      <p className="text-sm text-muted-foreground">{item.description}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* HOW TALENT MANAGEMENT WORKS */}
      <section className="py-20 lg:py-24 bg-muted/30">
        <div className="container mx-auto px-4 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">How Talent Management Works</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              A structured approach to building high-performing teams
            </p>
          </motion.div>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-5xl mx-auto"
          >
            {processSteps.map((step, index) => (
              <motion.div key={step.number} variants={itemVariants}>
                <Card className="p-6 h-full bg-card border-border/60 hover:shadow-md transition-all">
                  <div className="w-10 h-10 rounded-xl bg-secondary text-secondary-foreground flex items-center justify-center font-bold text-lg mb-4">
                    {step.number}
                  </div>
                  <h4 className="font-semibold text-foreground mb-2">{step.title}</h4>
                  <p className="text-sm text-muted-foreground leading-relaxed">{step.description}</p>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* CTA SECTION */}
      <section className="py-20 lg:py-24 bg-secondary">
        <div className="container mx-auto px-4 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="max-w-2xl mx-auto text-center"
          >
            <Users className="w-12 h-12 mx-auto mb-6 text-secondary-foreground/80" />
            <p className="text-secondary-foreground/70 text-sm font-medium uppercase tracking-wider mb-3">
              Ready to invest in your team?
            </p>
            <h3 className="text-3xl lg:text-4xl font-bold text-secondary-foreground mb-4">
              Let's Build a Thriving Workforce
            </h3>
            <p className="text-secondary-foreground/80 mb-8 leading-relaxed">
              Talk to our HR experts about creating a talent management strategy that improves engagement, performance, and retention.
            </p>
            <Button size="lg" variant="outline" asChild className="bg-secondary-foreground text-secondary hover:bg-secondary-foreground/90 border-0 shadow-md text-base h-11 px-6">
              <Link to="/contact">
                Talk to an HR Expert
                <ArrowRight className="w-4 h-4 ml-2" />
              </Link>
            </Button>
          </motion.div>
        </div>
      </section>
    </Layout>
  );
};

export default TalentManagement;
